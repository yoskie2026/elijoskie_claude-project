# Setting up the Elijoskie Humanize Field Guide GPT

## 1. Create the GPT
In ChatGPT, go to Explore GPTs, then Create, then open the Configure tab.

## 2. Fill in the fields

**Name**
Elijoskie Humanize Field Guide

**Description**
Genre-aware writing and editing that avoids documented AI writing patterns. Research, policy briefs, speeches, articles, grants, and fiction.

**Instructions**
Paste the full contents of INSTRUCTIONS.txt (about 6,000 characters; the field allows 8,000).

**Conversation starters**
- Draft a policy brief on this topic. I'll paste the evidence.
- Turn these notes into talking points for a keynote.
- Edit this grant narrative so it reads less like AI.
- Is this text AI-written? Check it against the field guide.

**Knowledge** (upload all 13 files from the knowledge folder)
genre-research.md, genre-policy-brief.md, genre-speech.md, genre-article-oped.md, genre-grant.md, genre-fiction.md, ref-surface.md, ref-grammar-and-stance.md, ref-structure.md, ref-integrity.md, ref-gpt-fingerprint.md, ref-sources.md, scan.py

**Capabilities**
- Code Interpreter & Data Analysis: ON (required to run scan.py)
- Web Search: ON (useful for checking citations and links)
- Image Generation: OFF
- Canvas: optional

## 3. Test before relying on it
1. Ask for a policy brief and a set of talking points on the same topic. Check that the two read differently.
2. Ask "write an article on X". It should ask whether you mean a research article or an op-ed.
3. Ask it to scan a paragraph. Check that it runs scan.py in Code Interpreter.
4. Paste a paragraph with American spellings. Check that it flags them.

## 4. Differences from the Claude skill
- The Claude fingerprint file is replaced by ref-gpt-fingerprint.md, which lists documented ChatGPT habits from the same sources.
- The fiction profile and structure reference now carry GPT fingerprints (gossip as plot device, distant retrospective narrator) instead of Claude's.
- A Claude skill opens its files on demand. A GPT retrieves pieces of knowledge files by search, which is less predictable. The Instructions therefore hold all the core rules and tell the GPT to open the genre file before drafting.

## 5. Before sharing publicly
- The speech profile contains your personal talking points format. Remove or generalise it if others will use the GPT.
- Check the current knowledge file limits in the GPT builder; the setup uses 13 files.
- Set sharing to "Only me" until testing is done.
