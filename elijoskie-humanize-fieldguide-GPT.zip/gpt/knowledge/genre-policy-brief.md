# Genre profile: policy briefs and memos

Covers: policy briefs, policy memos, position papers, briefing notes, background notes, recommendation papers.

## Evidence base
No AI-versus-human study of policy briefs was found. The closest evidence is on nonfiction and news (Russell et al. 2025; Shaib et al.; Munoz-Ortiz et al. 2024) and informational writing (Wikipedia). Items marked **[convention]** rest on policy writing conventions.

## Settings

| Setting | Policy setting |
|---|---|
| Stance | Clear position. The brief exists to argue for something. Hedge only where the evidence is uncertain. |
| Conclusions | **State them first and explicitly.** Lead with the problem and the recommendation. **[convention]** |
| Recommendations | Specific actor, specific action, specific timeframe or resource where known ("The Federal Ministry of X should..."). Numbered lists are acceptable. **[convention]** |
| Reader address | Rare. The reader is a decision-maker; address them through the recommendations. |
| Formatting | Headings, short sections, numbered recommendations, and boxes are normal. Avoid "**Label**: text" bullets used for everything. **[convention]** |
| Tone | Plain and direct. No promotional language (Wikipedia p. 5). |

## Policy-specific AI tells
- Recommendations with no actor: "Stakeholders should collaborate to foster an enabling environment." Name who does what.
- Vague attribution: "experts argue", "studies show" (Wikipedia p. 5). Name the source and page.
- Significance inflation: "a pivotal moment in the evolving policy landscape" (Wikipedia p. 3).
- The "Challenges and Future Outlook" closing formula (Wikipedia p. 6).
- Content that fits any country or sector. Use named states, laws, budgets, programmes, agencies, and figures. Low density and relevance are the strongest predictors of "slop" in expert annotation of news (Shaib et al., Section 5.1).
- Default optimism. State costs, risks, and trade-offs directly (Munoz-Ortiz et al.).

## Political content
Check that criticism and praise of governments are applied evenly. The Wikipedia page reports frontier models show a pro-authoritarian lean on some prompts (p. 39).

## Self-check
1. Can the main recommendation be found in the first paragraph?
2. Does every recommendation name an actor?
3. Are there local specifics (places, laws, figures) that would not fit another country?
4. Are trade-offs and risks stated plainly?
5. Is every figure sourced with a page or link?
