# Surface checklist

Source: Wikipedia, "Signs of AI writing", revision 1375746757 (page numbers refer to the 48-page print dated 19 Sept 2026). Each item gives the pattern, the words to watch as listed in the source, and the drafting instruction.

Read words literally. A flagged word does not make its synonyms suspect (p. 8). Context matters: "underscore" can mean an underline mark (p. 8).

## Contents
1. Content patterns
2. Language patterns
3. AI vocabulary by era
4. Formatting patterns
5. Chatbot leftovers
6. Historical patterns (older models)

## 1. Content patterns

**1.1 Undue emphasis on significance, legacy, broader trends (p. 3)**
Words: stands/serves as, is a testament/reminder, a crucial/pivotal/vital/significant/key role/moment, underscores/highlights its importance/significance, reflects broader, symbolizing its ongoing/enduring/lasting, contributing to the, setting the stage for, marking/shaping the, represents/marks a shift, key turning point, evolving landscape, focal point, indelible mark, deeply rooted.
Also: placing a subject amid broader "debates"; hedging that a subject is minor and then stressing its importance anyway; overstressing ecosystem links and conservation status for species.
Instruction: state the fact. Cut the claim about what it means for the wider world unless a named source makes that claim.

**1.2 Canned emphasis on notability and media coverage (pp. 3-4)**
Words: independent coverage, local/regional/national/[country] media outlets, music/business/tech outlets, trade publications, cited/featured/profiled in, written by a leading expert, active social media presence.
Instruction: say what the coverage reported. Do not describe the category of outlet as proof of importance.

**1.3 Superficial analyses (p. 4)**
Words: highlighting/underscoring/emphasizing..., ensuring..., reflecting/symbolizing..., contributing to..., cultivating/fostering..., encompassing..., enhancing..., valuable insights, align/resonate with.
Pattern: an "-ing" phrase attached to the end of a sentence to add interpretation. Newer models attach these to named sources whether or not the source says it.
Instruction: end the sentence at the fact. If interpretation is needed, attribute it to a source that actually makes it.

**1.4 Promotional and advertisement-like language (p. 5)**
Words: boasts a, vibrant, rich, profound, enhancing, showcasing, exemplifies, commitment to, natural beauty, nestled, in the heart of, groundbreaking, renowned, featuring, diverse array.
Note: newer models are more subtly positive than older ones and avoid blunt superlatives like "the best" (p. 5). Watch for press-release tone about people and organisations, and repeated reminders of "cultural heritage".
Instruction: describe, do not sell.

**1.5 Vague attributions and overgeneralization (p. 5)**
Words: Industry reports, Observers have cited, Experts argue, Some critics argue, several sources/publications (when few are cited), such as (before a list that is actually complete).
Instruction: name the source. Do not present one or two sources as a widely held view. Use "such as" only when more examples exist.

**1.6 Outline-like conclusions about challenges and prospects (p. 6)**
Words: Despite its..., faces several challenges..., Despite these challenges, Challenges and Legacy, Future Outlook.
Instruction: the problem is the rigid formula, not mentioning challenges. Do not close with "challenges, then vague optimism".

**1.7 Leads treating a broad title as a proper noun (pp. 6-7)** and **"Awards and recognition" or "X and Y" section headers (p. 7)**
Instruction: open with the subject itself. Avoid stock "X and Y" headers.

## 2. Language patterns

**2.1 Avoidance of basic copulas (pp. 8-9)**
Words: serves as, stands as, marks, functions as, operates as, represents [a]; boasts, features, maintains, offers [a]; refers to. Newer output uses longer versions ("ventured into politics as a candidate" for "was a candidate").
Evidence: one study found a drop of over 10% in "is" and "are" in academic writing in 2023 (p. 8).
Instruction: use is, are, has, was.

**2.2 Vague connection or association (p. 9)**
Words: in connection with/to, connected with/to, in association with, associated with.
Instruction: state the actual relationship.

**2.3 Negative parallelisms (pp. 9-11)**
Forms: "Not only ... but ...", "It is not just ..., it's ...", "It's not ..., it's ...", "no ..., no ..., just ...", and the reversed "Y rather than X" (common in Grok). Can run across several sentences using "however".
Instruction: state the point positively. Do not set up a misconception nobody held.

**2.4 Rule of three (p. 11)**
Forms: adjective, adjective, adjective; short phrase, short phrase, and short phrase. Used to make shallow analysis look complete.
Instruction: list as many items as exist.

## 3. AI vocabulary by era (pp. 7-8)

One or two of these may be coincidence. Many of them, many times, is one of the strongest tells (p. 7).

- **2023 to mid-2024 (GPT-4):** Additionally, boasts, bolstered, crucial, delve, emphasizing, enduring, garner, intricate/intricacies, interplay, key, landscape, meticulous/meticulously, pivotal, underscore, tapestry, testament, valuable, vibrant.
- **Mid-2024 to mid-2025 (GPT-4o):** align with, bolstered, crucial, emphasizing, enhance, enduring, fostering, highlighting, pivotal, showcasing, underscore, vibrant.
- **Mid-2025 onward (GPT-5):** emphasizing, enhance, highlighting, showcasing, plus the notability words in 1.2.
- **Full list in the source:** Additionally (sentence start), align with, boasts (meaning "has"), bolstered, crucial, deep dive, delve, emphasizing, enduring, enhance, fostering, garner, highlight (verb), interplay, intricate/intricacies, key (adjective), landscape (abstract noun), meticulous/meticulously, pivotal, robust, showcase, tapestry (abstract noun), testament, underscore (verb), valuable, vibrant.
- **Grok:** causal, empirical, correlate, and continued use of underscore (p. 8).

Instruction: when one of these appears, ask what specific fact it is standing in for, and write that fact.

**Transition words.** Only a few transitions are overused by AI in a formulaic way, mainly sentence-initial "Additionally" (p. 7), and transition words on their own are listed as ineffective indicators (p. 41). Human essay writers use more discourse markers than ChatGPT (Herbold et al. 2023). Keep connectives; vary them.

## 4. Formatting patterns

- **Title heading** repeating the document name at the top (p. 11).
- **Title case in headings** (p. 12). Use sentence case.
- **Headings that contain only other headings** (pp. 12-13).
- **Overuse of boldface**, especially bolding every instance of a key term (p. 13).
- **Inline-header vertical lists**: bullet, bold label, colon, text (pp. 13-14).
- **Em dashes** used more often than human writers of the same genre, often in a "punched up" sales style, often with spaces around them (p. 14). A July 2026 study (reported by The Economist) found Claude was the only contemporary model using more em dashes than professional writers.
- **Emoji as formatting** on headings or bullets (p. 15).
- **Small tables** for content better written as prose (p. 15).
- **Curly quotes** in ChatGPT and DeepSeek output; Claude and Gemini typically do not use them. Weak signal alone (pp. 15-16).
- **Skipped heading levels** and **thematic breaks (---) between sections** (p. 16).

## 5. Chatbot leftovers (pp. 16-19, 22-25, 30)

- Collaborative communication: I hope this helps, Of course!, Certainly!, You're absolutely right!, Would you like..., is there anything else, let me know, more detailed breakdown, here is a...
- Knowledge-cutoff and gap speculation: as of my last knowledge update, While specific details are limited/scarce..., not widely available/documented/disclosed, in the provided/available sources, based on available information, "maintains a low profile" (p. 18). The source says this content is speculative and may be fabricated.
- Placeholders: [Entertainer's Name], (Add your channel URL here), dates like 2025-xx-xx (pp. 18-19).
- Markdown leaking into a format that does not use it (pp. 20-22).
- Tool markup: contentReference, oaicite, oai_citation, turn0search0, attributableIndex (ChatGPT); [cite: 1], [span_1](start_span) (Gemini); grok_card (Grok); 【85†L261-269】 (DeepSeek); [attached_file:1], [web:1], ppl-ai-file-upload (Perplexity); :::writing{variant="document"...} (unclassified) (pp. 22-25).
- Tracking parameters in URLs: utm_source=chatgpt.com, utm_source=openai, utm_source=copilot.com, referrer=grok.com (p. 30). Strip them.

## 6. Historical patterns (older models, pp. 41-44)

Less common in current output but still worth removing:
- Didactic disclaimers: it's important/critical/crucial to note/remember/consider, worth noting, may vary.
- Section summaries: In summary, In conclusion, Overall, restating the point just made.
- Refusal text: as an AI language model, I'm sorry...
- Elegant variation: cycling through synonyms to avoid repeating a word. Note that some non-native writers are taught to do this (p. 44).
