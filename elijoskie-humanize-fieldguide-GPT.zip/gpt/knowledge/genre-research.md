# Genre profile: research and academic writing

Covers: journal articles, working papers, desk reviews, literature reviews, abstracts, theses, methodology sections, findings reports.

## Evidence base
Direct evidence: Herbold et al. 2023 (argumentative essays), Jiang and Hyland 2025 (argumentative essays), Reinhart et al. 2025 (includes academic-register text), Kobak et al. 2025 and Geng and Trotta (academic abstracts, via Wikipedia pp. 7-8). Items marked **[convention]** rest on academic writing conventions, not AI-versus-human studies.

## Settings

| Setting | Research setting |
|---|---|
| Stance | Visible but measured. Hedge claims to the strength of the evidence ("suggests", "may", "is consistent with"). Commit firmly where the data is strong. ChatGPT essays use fewer modals and epistemic markers than human writers (Herbold et al.). |
| Conclusions | **State them explicitly.** This overrides the StoryScope rule against stating the theme. Findings, implications, and recommendations must be written out. |
| Self-mention | "We" or "I" where the discipline allows it. **[convention]** |
| Reader address | None. No rhetorical "you". |
| Passive voice | Acceptable, especially in methods. |
| Nominalizations | Keep established technical terms. Cut decorative ones ("the operationalization of the enhancement"). AI uses 1.5 to 2 times the human rate (Reinhart et al.). |
| Connectives | Varied and frequent. Human essay writers use more discourse markers (Herbold et al.). Avoid the repeated sentence-initial "Additionally". |
| Formatting | Follow the journal, institution, or template. Headings such as Introduction, Methods, Results, Discussion are expected. **[convention]** |
| Paragraphs | Develop an argument over several sentences. Avoid one-point-per-short-paragraph. |

## Research-specific AI tells
- "Is" and "are" replaced by "serves as", "represents", "stands as". One study found a decline of over 10% in "is" and "are" in academic writing in 2023 (Wikipedia p. 8).
- Excess vocabulary found in abstracts: delve, underscore, pivotal, intricate, meticulous, showcase, crucial (Wikipedia pp. 7-8).
- Significance inflation in introductions and conclusions ("this study makes a pivotal contribution to the evolving landscape").
- Formulaic limitations section: "Despite these limitations, the study offers valuable insights... future research should explore..." (Wikipedia p. 6). Name the actual limitations and their effect on the findings.
- Vague literature summaries ("scholars have argued", "several studies show") without named authors (Wikipedia p. 5).
- Fabricated or unverifiable citations; book citations without page numbers (Wikipedia pp. 27-29).

## Self-check
1. Is every claim either cited with a page or clearly the author's own finding?
2. Are hedges matched to the evidence, with firm statements where the data is strong?
3. Are conclusions and implications stated plainly?
4. Is the limitations section specific to this study?
5. Are named authors used instead of "scholars argue"?
6. Does any paragraph end with an "-ing" clause interpreting significance?
