# Genre profile: articles, op-eds, and essays

Covers: op-eds, opinion pieces, essays, feature articles, blog posts, newsletters, commentary, thought leadership, LinkedIn articles.

## Evidence base
Direct evidence: Russell et al. 2025 (nonfiction articles, expert detection), Shaib et al. (news "slop"), Munoz-Ortiz et al. 2024 (news), Herbold et al. 2023 and Jiang and Hyland 2025 (argumentative essays). Items marked **[convention]** rest on convention only.

## Settings

| Setting | Article setting |
|---|---|
| Stance | Visible and personal in op-eds and essays. The writer takes a position and defends it. Human essays are richer in engagement features, especially questions and personal asides (Jiang and Hyland). |
| Self-mention | "I" and "we" are normal in op-eds and essays. Features and news-style articles use less. **[convention]** |
| Reader address | Allowed and often useful: questions, direct appeals. |
| Emotion | Negative emotion is allowed. Human news text shows stronger negative emotions and less joy than LLM text (Munoz-Ortiz et al.). |
| Conclusions | Make the argument clear. Do not end on an optimistic but vague note or the "future outlook" formula (Wikipedia p. 6). |
| Evidence | Named sources, real quotes, specific numbers, concrete examples. |
| Originality | Make at least one point the reader has not seen many times. Experts cite originality as a detection clue (Russell et al.). |
| Formatting | Mostly prose. Subheadings only if the publication uses them. |

## Article-specific AI tells
- Hook-and-summary structure: generic opening question, three evenly weighted sections, uplifting conclusion.
- Formality that does not fit the publication (Russell et al.).
- Every paragraph the same length.
- Rhetorical contrast used as filler: "It's not just about X; it's about Y" (Wikipedia pp. 9-10).
- Generic claims that fit any topic; low density (Shaib et al.).

## Self-check
1. Can the argument be stated in one sentence, and does the piece argue it?
2. Is there a named source, a real example, or a quote in most sections?
3. Does the writer's view appear, with firm claims and honest doubts?
4. Is the ending specific to this argument?
5. Would an editor at the target publication recognise the register as theirs?
