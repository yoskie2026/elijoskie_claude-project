#!/usr/bin/env python3
"""Genre-aware scanner for the Elijoskie Humanize Field Guide GPT.

Reports three things:
  1. Surface pattern candidates (Wikipedia "Signs of AI writing").
  2. Rhythm, grammar, and stance metrics (Reinhart, Herbold, Munoz-Ortiz, Ju et al.).
  3. English spelling consistency (default: British spelling as used in Nigeria).

It flags candidates only. Context decides. Metric thresholds are heuristics set
for this skill, not values taken from the studies.

Usage:
  python scan.py FILE --genre research|policy|speech|article|grant|fiction [--variety british|american]
  cat draft.txt | python scan.py - --genre speech
"""
import argparse
import re
import statistics
import sys

GENRES = ["research", "policy", "speech", "article", "grant", "fiction"]

# (category, source, regex, flags, genres where the check is relaxed to "check deliberate/allowed")
SURFACE = [
    ("Em dash", "Wikipedia p.14", r"\u2014", 0, []),
    ("AI vocabulary", "Wikipedia pp.7-8",
     r"\b(additionally|bolster(s|ed|ing)?|crucial|deep dive|delv(e|es|ed|ing)|enduring|enhanc(e|es|ed|ing)|"
     r"foster(s|ed|ing)?|garner(s|ed|ing)?|interplay|intricac(y|ies)|intricate|meticulous(ly)?|pivotal|"
     r"robust|showcas(e|es|ed|ing)|tapestr(y|ies)|testament|underscor(e|es|ed|ing)|vibrant|align(s|ed)? with|"
     r"key (role|factor|moment|insight|driver)s?|(evolving|changing|digital|policy|media|political) landscape)\b", re.I, []),
    ("Significance puffery", "Wikipedia p.3",
     r"(stands as|serves as|is a (testament|reminder)|(crucial|pivotal|vital|significant|key) (role|moment)|"
     r"reflects broader|setting the stage for|marks? a shift|represents a shift|turning point|"
     r"focal point|indelible mark|deeply rooted|(ongoing|enduring|lasting) (legacy|significance|impact))", re.I, []),
    ("Notability / coverage talk", "Wikipedia pp.3-4",
     r"(independent coverage|media outlets|trade publications|(featured|profiled) in|leading expert|"
     r"active social media presence)", re.I, []),
    ("Trailing -ing analysis", "Wikipedia p.4; Reinhart",
     r",\s+(highlighting|underscoring|emphasizing|emphasising|ensuring|reflecting|symbolizing|symbolising|"
     r"contributing to|cultivating|fostering|encompassing|enhancing|showcasing|demonstrating|signaling|signalling)\b", re.I, []),
    ("Promotional language", "Wikipedia p.5",
     r"\b(boasts?|nestled|in the heart of|groundbreaking|renowned|diverse array|natural beauty|"
     r"commitment to|exemplif(y|ies)|world-class|state-of-the-art|transformative)\b", re.I, []),
    ("Vague attribution", "Wikipedia p.5",
     r"(industry reports|observers (have|note|say)|experts (argue|say|note|believe|agree)|some critics|"
     r"several (sources|publications)|studies (show|suggest|have shown)|research (shows|suggests))", re.I, []),
    ("Challenges / outlook formula", "Wikipedia p.6",
     r"(despite (its|these|their|this)\b.{0,60}challenges|faces? (several|many|numerous|significant) challenges|"
     r"future (outlook|prospects)|the future (looks|is) (bright|promising))", re.I, []),
    ("Copula avoidance", "Wikipedia p.8",
     r"\b(serves as|stands as|functions as|operates as)\b", re.I, []),
    ("Vague connection", "Wikipedia p.9",
     r"(in connection with|connected (with|to)|in association with)", re.I, []),
    ("Negative parallelism", "Wikipedia pp.9-11",
     r"(not only\b.{0,80}\bbut|it'?s not (just|merely|only|about)?\s*[^.]{0,60}[,;]\s*it'?s|"
     r"\bnot\b[^.]{1,40}\bbut rather\b|\bno\b\s\w+,\s*no\b\s\w+,\s*just\b)", re.I, []),
    ("Adjective or short-phrase triad", "Wikipedia p.11",
     r"\b\w+(ly)?\s?\w*,\s+\w+\s?\w*,\s+and\s+\w+\s?\w*\b", 0, ["speech"]),
    ("Chatbot leftovers", "Wikipedia pp.16-17",
     r"(i hope this helps|certainly!|of course!|you'?re absolutely right|would you like (me )?to|"
     r"let me know if|is there anything else|feel free to)", re.I, []),
    ("Gap speculation", "Wikipedia p.18",
     r"(as of my last|knowledge (cutoff|update)|not widely (available|documented|disclosed)|"
     r"details are (limited|scarce)|based on available information|maintains a low profile)", re.I, []),
    ("Placeholder", "Wikipedia pp.18-19",
     r"(\[[A-Z][^\]]{2,40}\]|\((add|insert) [^)]+\)|20\d\d-(xx|XX)-(xx|XX))", 0, []),
    ("Tool markup", "Wikipedia pp.22-25",
     r"(contentReference|oaicite|oai_citation|turn0(search|image|news|file)\d+|attributableIndex|"
     r"\[cite:\s*\d|start_span|end_span|grok_card|\u3010\d+\u2020|\[attached_file:|\[web:\d|"
     r"ppl-ai-file-upload|:::writing)", re.I, []),
    ("Tracking parameter in URL", "Wikipedia p.30",
     r"(utm_source=|referrer=grok\.com)", re.I, []),
    ("Bold-label list item", "Wikipedia pp.13-14",
     r"^\s*([-*\u2022]|\d+\.)\s+\*\*[^*]+\*\*\s*:", re.M, ["policy", "grant"]),
    ("Emoji", "Wikipedia p.15", r"[\U0001F300-\U0001FAFF\u2600-\u27BF]", 0, []),
    ("Didactic disclaimer", "Wikipedia p.41",
     r"(it'?s (important|critical|crucial|worth) (to )?(note|noting|remember|consider)|worth noting)", re.I, []),
    ("Summary capper", "Wikipedia p.42",
     r"^\s*(in summary|in conclusion|overall|to sum up),", re.I | re.M, []),
    ("Repeated 'Additionally'", "Wikipedia p.7", r"(^|[.!?]\s+)Additionally,", re.M, []),
]

HEDGES = r"\b(may|might|could|perhaps|possibly|likely|suggests?|appears?|seems?|tends? to|arguably|in my view|i think|we think|i believe|probably|to some extent)\b"
BOOSTERS = r"\b(clearly|certainly|definitely|undoubtedly|must|always|never|without doubt|in fact|of course)\b"
SELF = r"\b(i|me|my|we|our|us)\b"
READER = r"\b(you|your|yours)\b"
QUESTION = r"\?"
NOMINAL = r"\b[a-z]{4,}(tion|tions|ment|ments|ness|ity|ities|ance|ances|ence|ences|isation|ization)\b"
PARTICIPLE_CLAUSE = r",\s+[a-z]+ing\b"
CONNECTIVES = ["however", "because", "so", "yet", "still", "although", "though", "but", "therefore",
               "thus", "instead", "meanwhile", "even so", "for example", "in fact", "as a result",
               "moreover", "furthermore", "additionally", "also", "while", "since"]

AM_BR = [  # (american regex, british form)
    (r"\b(organiz|recogniz|realiz|prioritiz|mobiliz|analyz|emphasiz|summariz|utiliz|minimiz|maximiz|criticiz|civiliz|apologiz|optimiz|standardiz|digitaliz|characteriz|operationaliz|finaliz|specializ)(e|es|ed|ing|ation|ations)\b", "-ise"),
    (r"\b(color|behavior|favor|honor|labor|neighbor|harbor|rumor|humor|vapor)(s|ed|ing|able|ite)?\b", "-our"),
    (r"\b(center|theater|meter|liter|fiber)s?\b", "-re"),
    (r"\bprogram(s)?\b(?! (code|file))", "programme (non-software)"),
    (r"\b(defense|offense|license)\b", "-ence (noun)"),
    (r"\b(traveled|traveling|traveler|modeling|labeled|labeling|canceled|canceling)\b", "doubled l"),
]
BR_PAT = r"\b(organis|recognis|realis|prioritis|mobilis|analys|emphasis|summaris|utilis|minimis|maximis|criticis|optimis|standardis|characteris|operationalis|finalis|specialis)(e|es|ed|ing|ation|ations)\b|\b(colour|behaviour|favour|honour|labour|neighbour|centre|theatre|programme|defence|travelled|travelling|labelled)\b"

# Heuristic thresholds by genre (not from the studies)
# sentence length coefficient of variation minimum; stance/reader expectations
GENRE_EXPECT = {
    "research": {"cv_min": 0.35, "hedges": "expected", "self": "optional", "reader": "avoid", "questions": "rare"},
    "policy":   {"cv_min": 0.35, "hedges": "where uncertain", "self": "optional", "reader": "rare", "questions": "rare"},
    "speech":   {"cv_min": 0.50, "hedges": "light", "self": "expected", "reader": "expected", "questions": "expected"},
    "article":  {"cv_min": 0.45, "hedges": "expected", "self": "expected (op-ed/essay)", "reader": "allowed", "questions": "allowed"},
    "grant":    {"cv_min": 0.35, "hedges": "light", "self": "expected (we/our organisation)", "reader": "avoid", "questions": "rare"},
    "fiction":  {"cv_min": 0.50, "hedges": "n/a", "self": "n/a", "reader": "optional", "questions": "n/a"},
}


def sentences(text):
    body = re.sub(r"^\s*(#{1,6}\s.*|[-*\u2022]\s.*|\d+\.\s.*)$", "", text, flags=re.M)
    parts = re.split(r"(?<=[.!?])\s+(?=[A-Z\"'(])", body)
    return [p.strip() for p in parts if len(re.findall(r"\w+", p)) >= 2]


def paragraphs(text):
    return [p for p in re.split(r"\n\s*\n", text) if len(re.findall(r"\w+", p)) >= 15]


def per100(count, words):
    return round(100.0 * count / max(words, 1), 2)


def line_of(text, pos):
    return text.count("\n", 0, pos) + 1


def scan(text, genre, variety):
    words = re.findall(r"[A-Za-z']+", text)
    n = len(words)
    out = []

    # 1. Surface
    out.append("## 1. Surface pattern candidates")
    any_hit = False
    for cat, src, pat, flags, relaxed in SURFACE:
        hits = list(re.finditer(pat, text, flags))
        if not hits:
            continue
        any_hit = True
        note = " (allowed if deliberate in this genre)" if genre in relaxed else ""
        out.append(f"[{cat}] x{len(hits)} ({src}){note}")
        for m in hits[:6]:
            s, e = max(0, m.start() - 35), min(len(text), m.end() + 35)
            out.append(f"   line {line_of(text, m.start())}: ...{text[s:e].strip()}...".replace("\n", " "))
        if len(hits) > 6:
            out.append(f"   (+{len(hits) - 6} more)")
    for i, line in enumerate(text.splitlines(), 1):
        m = re.match(r"^\s*#{1,6}\s+(.*)$", line)
        if m:
            ws = [w for w in re.findall(r"[A-Za-z][A-Za-z'-]*", m.group(1))[1:] if len(w) > 3]
            if len(ws) >= 2 and all(w[0].isupper() for w in ws):
                any_hit = True
                out.append(f"[Title-case heading] line {i}: {line.strip()} (Wikipedia p.12)")
    if not any_hit:
        out.append("No surface candidates.")

    # 2. Rhythm
    out.append("\n## 2. Rhythm (Munoz-Ortiz et al.; Ju et al.)")
    sents = sentences(text)
    lens = [len(re.findall(r"\w+", s)) for s in sents]
    exp = GENRE_EXPECT[genre]
    if len(lens) >= 5:
        mean = statistics.mean(lens)
        sd = statistics.pstdev(lens)
        cv = sd / mean if mean else 0
        short = sum(1 for x in lens if x <= 8)
        long_ = sum(1 for x in lens if x >= 30)
        out.append(f"Sentences: {len(lens)} | mean {mean:.1f} words | SD {sd:.1f} | variation (CV) {cv:.2f} | "
                   f"short (<=8): {short} | long (>=30): {long_}")
        if cv < exp["cv_min"]:
            out.append(f"   FLAG: sentence lengths are uniform for a {genre} text (heuristic minimum CV {exp['cv_min']}). "
                       f"Add some short and some long sentences.")
        if short == 0:
            out.append("   FLAG: no short sentences.")
        if long_ == 0 and genre in ("research", "article", "policy") and len(lens) >= 15:
            out.append("   NOTE: no long sentences; human text keeps a long tail.")
    else:
        out.append("Too few sentences to measure.")
    paras = paragraphs(text)
    if len(paras) >= 4:
        plens = [len(re.findall(r"\w+", p)) for p in paras]
        pcv = statistics.pstdev(plens) / statistics.mean(plens)
        out.append(f"Paragraphs: {len(paras)} | mean {statistics.mean(plens):.0f} words | variation (CV) {pcv:.2f}")
        if pcv < 0.25:
            out.append("   FLAG: paragraphs are near-identical in length. Let some develop further; merge some.")

    # 3. Grammar
    out.append("\n## 3. Grammar (Reinhart et al.; Herbold et al.)")
    lower = text.lower()
    nom = len(re.findall(NOMINAL, lower))
    part = len(re.findall(PARTICIPLE_CLAUSE, lower))
    out.append(f"Nominalizations: {per100(nom, n)} per 100 words (counts suffixes; includes legitimate terms)")
    out.append(f"Comma + '-ing' clauses: {per100(part, n)} per 100 words")
    if per100(part, n) > 0.8:
        out.append("   FLAG: frequent participial add-on clauses. Split or rewrite some.")
    if genre in ("speech", "article", "fiction") and per100(nom, n) > 4:
        out.append(f"   FLAG: noun-heavy for a {genre} text. Turn some nouns back into verbs.")

    # 4. Stance and engagement
    out.append("\n## 4. Stance and engagement (Herbold et al.; Jiang and Hyland)")
    h = len(re.findall(HEDGES, lower))
    b = len(re.findall(BOOSTERS, lower))
    s_ = len(re.findall(SELF, lower))
    r_ = len(re.findall(READER, lower))
    q = len(re.findall(QUESTION, text))
    out.append(f"Hedges {per100(h, n)} | boosters {per100(b, n)} | self-mention {per100(s_, n)} | "
               f"reader address {per100(r_, n)} | questions {q}   (per 100 words)")
    out.append(f"Expected for {genre}: hedges {exp['hedges']}; self-mention {exp['self']}; "
               f"reader address {exp['reader']}; questions {exp['questions']}")
    if exp["hedges"] == "expected" and h == 0:
        out.append("   FLAG: no hedges. Add qualification where the evidence is uncertain.")
    if exp["self"].startswith("expected") and s_ == 0:
        out.append("   FLAG: no first person; the writer is absent.")
    if exp["reader"] == "expected" and r_ == 0:
        out.append("   FLAG: the audience is never addressed.")
    if exp["reader"] == "avoid" and r_ > 0:
        out.append("   CHECK: 'you' appears; confirm it is not rhetorical reader address.")
    used = [c for c in CONNECTIVES if re.search(r"\b" + re.escape(c) + r"\b", lower)]
    out.append(f"Distinct connectives used: {len(used)} ({', '.join(used[:12])})")
    if n > 300 and len(used) < 4:
        out.append("   FLAG: few connectives; ideas may be stacked, not linked.")

    # 5. Spelling
    out.append(f"\n## 5. English variety (target: {variety}; Wikipedia p.36)")
    am = []
    for pat, label in AM_BR:
        for m in re.finditer(pat, text, re.I):
            am.append((m.group(0), label, line_of(text, m.start())))
    br = [m.group(0) for m in re.finditer(BR_PAT, text, re.I)]
    if variety == "british":
        if am:
            out.append(f"American spellings found: {len(am)}")
            for w, label, ln in am[:10]:
                out.append(f"   line {ln}: '{w}' (British {label})")
        else:
            out.append("No American spellings found.")
    else:
        if br:
            out.append(f"British spellings found: {len(br)}: {', '.join(br[:10])}")
        else:
            out.append("No British spellings found.")
    if am and br:
        out.append("   FLAG: mixed spelling varieties.")
    return f"Words: {n} | Genre: {genre}\n\n" + "\n".join(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("file")
    ap.add_argument("--genre", choices=GENRES, required=True)
    ap.add_argument("--variety", choices=["british", "american"], default="british")
    a = ap.parse_args()
    text = sys.stdin.read() if a.file == "-" else open(a.file, encoding="utf-8").read()
    print(scan(text, a.genre, a.variety))


if __name__ == "__main__":
    main()
