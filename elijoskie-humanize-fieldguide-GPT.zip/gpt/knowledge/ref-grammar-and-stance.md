# Grammar, stance, rhythm, and register: findings from other studies

These studies add what Wikipedia and StoryScope do not cover: grammar-level patterns, the writer's stance, sentence rhythm, and register fit. Full citations and links are in `sources.md`. Each entry states the genre studied, because findings do not automatically transfer.

## 1. Register and grammar
**Reinhart et al. 2025, PNAS (peer-reviewed). Multiple genres; GPT-4o, GPT-4o Mini, Llama 3.**
- Instruction-tuned models write in a noun-heavy, informationally dense style, even when prompted to write informally.
- Present participial clauses: 2 to 5 times the human rate.
- Nominalizations: 1.5 to 2 times the human rate.
- Agentless passive: GPT-4o at about half the human rate.
- Strong preferences for "that" clauses as subjects and phrasal coordination.
- Base (non-instruction-tuned) models were closer to human rates, so the gap comes from instruction tuning.
- The authors describe the result as genre misalignment: the models struggle to match human stylistic variation.

**Rules drawn:** match the genre's register; limit participial "-ing" clauses; cut decorative nominalizations; normal passive is fine.

## 2. Stance and modality
**Herbold et al. 2023, Scientific Reports (peer-reviewed). Argumentative essays; German high-school students vs ChatGPT-3 and ChatGPT-4.**
- ChatGPT used more nominalizations and more complex sentences.
- Students used more modals and epistemic markers (for example "I think", "in my opinion"), which signal the writer's attitude.
- The AI essays had fewer discourse markers.
- ChatGPT-4 showed higher lexical diversity than the students; ChatGPT-3 showed lower.
- Teachers rated the ChatGPT essays higher. "Sounding human" and "being rated well" are different targets.

**Jiang and Hyland 2025, Written Communication 42(3) (peer-reviewed). 145 student essays vs 145 ChatGPT essays.**
- Student essays were richer in the number and variety of engagement markers.
- ChatGPT used fewer questions and personal asides.

**Rules drawn:** show stance through hedges, commitments, and self-mention as the genre allows; use varied connectives; address the reader where the genre invites it.

## 3. Rhythm and distribution
**Munoz-Ortiz, Gomez-Rodriguez, and Vilares 2024, Artificial Intelligence Review (peer-reviewed). News; six open LLMs.**
- Human texts have more scattered sentence-length distributions and more varied vocabulary.
- Humans show stronger negative emotions (fear, disgust) and less joy.
- LLM outputs use more numbers, symbols, auxiliaries, and pronouns.
- Differences between LLMs and humans were larger than differences between LLMs.
- Note: models tested were 2023 open models; the vocabulary finding conflicts with Herbold's GPT-4 result.

**Ju, Blix, and Williams 2025, Findings of ACL (peer-reviewed). Wikipedia, news, ELI5; Llama and Mistral models.**
- Regenerated text mostly showed a shifted mean, a lower standard deviation, and a shorter long tail than the human originals.
- The authors read this as the models simplifying relative to the human domain and missing rarer structures.

**Rules drawn:** vary sentence and paragraph length, including outliers; do not default to positive framing; do not chase vocabulary variety for its own sake.

## 4. Quality: density, relevance, templates
**Shaib et al. (preprint, arXiv:2509.19163v2). News and question answering; expert copy-editors.**
- Taxonomy: information utility (density, relevance), information quality (factuality, bias), style quality (repetition, templatedness, coherence, fluency, verbosity, word complexity, tone).
- Relevance, density, and tone were the strongest predictors of a "slop" judgement (Section 5.1).
- What matters differs by genre: factual and structural issues for question answering; style and utility issues for news.
- The "bias" code includes text that is too objective where a point of view is needed.
- GPT-5, DeepSeek-V3, and o3-mini agreed poorly with human judges (kappa near 0) and were weak at finding the problem spans (Table 7).

**Chakrabarty, Laban, and Wu 2025, CHI (peer-reviewed). Creative writing domains; 18 professional writers editing LLM text.**
- Seven categories: cliche; unnecessary or redundant exposition; purple prose; poor sentence structure; lack of specificity and detail; awkward word choice and phrasing; tense inconsistency.
- Similar idiosyncrasies across the three model families tested.

**Rules drawn:** cut filler and restatement; stay on the task; avoid templated sentence patterns; do not rely on the model's self-review alone.

## 5. What experts notice
**Russell, Karpinska, and Iyyer 2025, ACL (peer-reviewed). 300 nonfiction articles; GPT-4o, Claude, o1.**
- Frequent LLM users detected AI text with high accuracy; a five-expert majority misclassified 1 of 300 articles.
- Clue frequencies in explanations: vocabulary 53.1%, sentence structure 35.9%, grammar 24.8%, originality 23.7%.
- Formality, originality, and clarity were among the harder, higher-level clues.

**Rules drawn:** vocabulary cleanup is necessary but not enough; register fit and originality matter.

## 6. Fairness warning
**Liang et al. 2023, Patterns (peer-reviewed opinion paper with original data).**
- Detectors misclassified over half of non-native English TOEFL essays as AI-generated; accuracy on native samples was near perfect.
- Making word choice more sophisticated reduced misclassification; simplifying native writing increased it.

**Rules drawn:** never inflate vocabulary to beat a detector; simple, plain vocabulary is not a sign of AI.

## Where the studies disagree
| Question | Finding A | Finding B | How the skill handles it |
|---|---|---|---|
| Transition words | Wikipedia: sentence-initial "Additionally" is an AI tell | Herbold: humans use more discourse markers overall | The tell is one repeated formula; varied connectives are human |
| Vocabulary variety | Munoz-Ortiz: humans more varied (2023 open models) | Herbold: GPT-4 more varied than students; Wikipedia: synonym-cycling is an older AI tell | Do not push for variety; repeat the right word |
| Passive voice | Common style advice: avoid passive | Reinhart: GPT-4o uses agentless passive at half the human rate | Normal passive is fine where the genre uses it |
