# Genre profile: grant proposals and donor documents

Covers: grant proposals, concept notes, expressions of interest, funding applications, RFP responses, proposal narratives, donor reports.

## Evidence base
No AI-versus-human study of grant proposals was found. This profile applies the universal rules and the Wikipedia content patterns, which are especially relevant because proposals invite self-promotion. Items marked **[convention]** rest on funder conventions.

## Settings

| Setting | Grant setting |
|---|---|
| Structure | **Follow the funder's template and headings exactly.** The call for proposals overrides this skill's formatting rules. **[convention]** |
| Objectives | Explicit and measurable. No ambiguity. This overrides the StoryScope rule on leaving points open. |
| Stance | Confident about the organisation's plan; honest about risks. |
| Evidence of need | Figures with named sources and pages. |
| Organisation description | Facts: years operating, named projects, numbers reached, named partners and funders. No puffery. |
| Formatting | Tables, numbered objectives, and logframes are normal where the template asks for them. |

## Grant-specific AI tells
- Promotional language about the organisation: renowned, commitment to, groundbreaking, "a proven track record" without numbers (Wikipedia p. 5).
- Notability claims by media type: "featured in national media outlets" instead of what was reported (Wikipedia pp. 3-4).
- Activities with no named place, partner, number, or date.
- Risk sections written as the "challenges" formula instead of named risks with named mitigations (Wikipedia p. 6).
- Impact statements about "lasting change" and "transformative impact" with no indicator (Wikipedia p. 3).

## Self-check
1. Does every section match the funder's heading and word limit?
2. Is every objective measurable, with an indicator?
3. Does every claim about the organisation carry a number, date, or named example?
4. Are risks specific, each with a mitigation?
5. Is every statistic sourced?
