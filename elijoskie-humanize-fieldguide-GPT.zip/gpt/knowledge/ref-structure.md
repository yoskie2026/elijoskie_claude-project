# Structural checklist

Source: Russell, Rajendhran, Iyyer, Wieting, "StoryScope: Investigating idiosyncrasies in AI fiction", arXiv:2604.03136v1 (3 April 2026), preprint under review. Page and table numbers refer to that version.

## Scope warning

StoryScope studied fiction only: about 5,000-word short stories written by humans (from published anthologies) and by Claude Sonnet 4.6, GPT-5.4, Gemini 3 Flash, DeepSeek V3.2, and Kimi K2.5 (pp. 3, 17). The features were found by GPT-5.1 and scored by Gemini 3 Flash, with human validation on 12 stories (p. 19).

Genre files decide how these apply. Each feature below is marked:
- **NF**: carries over to nonfiction (speeches, briefs, articles, talking points, proposals). This transfer is an adaptation, not something the paper tested.
- **F**: applies to fiction and narrative pieces only.

## Why this layer matters

- Narrative features alone separated human from AI stories at 93.2% macro-F1, without any style features (Table 2, p. 6).
- After AI stories were edited to remove surface artifacts, detection from structure dropped only from 95.5% to 93.9% (p. 8).
- AI stories cluster together in one region of narrative space. Human stories are more spread out and rarer (pp. 8-9, 22-23).

## The 30 core features (Table 15, p. 26)

Figures are human value versus AI average. Percentages are prevalence; decimals are means on 1-5 or ordinal scales.

### A. AI over-explains its themes

| Feature | Human | AI | Rule | Scope |
|---|---|---|---|---|
| Thematic explicitness and moralizing | 3.28 | 3.94 | Do not state the moral or lesson. Let the material carry it. | NF, F |
| Narratorial thematic commentary (yes) | 52% | 77% | No closing lines explaining what it all means. | NF, F |
| Moral/philosophical weighting | 3.26 | 3.68 | Do not raise every point to a moral question. | NF, F |
| Thematic unity | 4.41 | 4.74 | Not every detail has to serve one central theme. | NF, F |
| Dialogue as philosophical debate | 34% | 59% | Characters (or quoted speakers) should not trade position statements. | F |
| References as implicit echoes | 50% | 72% | Name the work, person, or document. Avoid vague allusion. | NF, F |

### B. AI over-writes the body and senses

| Feature | Human | AI | Rule | Scope |
|---|---|---|---|---|
| Emotion conveyed through the body | 38% | 81% | Name the feeling when that is the point ("was afraid"). | F (NF for speeches with stories) |
| Setting as psychological mirror | 3.58 | 4.07 | Do not make weather and rooms reflect moods by default. | F |
| Environmental/ecological emphasis | 2.83 | 3.21 | Do not add nature and environment detail by habit. | F |
| Olfactory imagery present | 57% | 82% | Do not add smells by habit. | F |
| Sensory density | 3.66 | 3.93 | Lower the default level of sensory description. | F |
| Depth of interior access | 3.67 | 3.93 | Not every character's inner state needs narrating. | F |

### C. AI streamlines structure

| Feature | Human | AI | Rule | Scope |
|---|---|---|---|---|
| Continuity of one causal chain | 3.92 | 4.20 | Allow side points and breaks where the material has them. | NF, F |
| Resolution by protagonist's choice | 46% | 69% | Outcomes can come from outside forces, not only the actor's decision. | F (NF: case stories, success stories) |
| No subplots | 57% | 79% | Include secondary threads where real. | F |
| Resolution through internal understanding | 27% | 47% | Do not end on "and so they understood/accepted". | NF, F |
| Character introduced by external description | 30% | 52% | Introduce people through what they do or say. | F |
| Spatial granularity | 2.27 | 2.53 | Less room-by-room physical detail. | F |
| Opening spatial grounding | 2.12 | 2.33 | Do not always open by setting the scene. | NF, F |
| Pre-threat character investment | 2.76 | 2.99 | Get to the problem sooner. | NF, F |

### D. Human writing engages the outside world

| Feature | Human | AI | Rule | Scope |
|---|---|---|---|---|
| Explicit named references | 47% | 24% | Name specific texts, authors, reports, laws, people. | NF, F |
| Balanced mix of explicit and implicit references | 37% | 16% | Mix named references with lighter allusions. | NF, F |
| Fourth-wall permeability | 0.67 | 0.39 | Allowed where the genre invites it; not required. | See genre files |
| Direct reader address | 0.28 | 0.07 | Allowed where the genre invites it; not required. | See genre files |

The paper also notes AI avoids naming real brands, places, or works (p. 7).

**Note on reader address.** The paper's text (p. 7) reports these two features as percentages ("67% vs. 39%", "28% vs. 7%"), but Table 15 reports the same numbers as means on ordinal scales. "No direct address" is also listed as a human fingerprint feature (Table 16, p. 27). Read together, most human stories also do not address the reader. The skill therefore treats reader address as allowed where the genre invites it (speeches, op-eds), never as required, and never in research writing.

### E. Human writing is less linear

| Feature | Human | AI | Rule | Scope |
|---|---|---|---|---|
| Recontextualization after surprise | 3.28 | 2.95 | A later point can change how earlier points read. | F (NF: case narratives) |
| Chronological discontinuity | 2.40 | 2.12 | Time jumps are allowed. | F (NF: stories inside speeches) |
| Nonlinear framing for delayed disclosure | 1.96 | 1.68 | Hold back a key fact where it serves the piece. | F |
| Anachrony (flashback/flashforward) | 2.58 | 2.31 | Use flashbacks where they help. | F |

### F. Human writing is more varied

| Feature | Human | AI | Rule | Scope |
|---|---|---|---|---|
| Location variety | 1.34 | 1.08 | More than one setting where the story allows. | F |
| Dialogue-to-narration proportion | 2.95 | 2.70 | More direct speech; quote real people in nonfiction. | NF, F |
| Subplots thematically parallel | 42% | 21% | Secondary threads can echo the main one. | F |
| Morally ambivalent protagonist | 59% | 38% | People can be mixed, not clearly good or bad. | NF (profiles, case stories), F |
| Explicit emotion labels | 29% | 8% | Plain naming of feelings is normal. | NF, F |

## Narration features from Table 16 (p. 27)

Two narration fingerprints give a direction that matters for this GPT:
- **Breadth of focalization, single focal character:** elevated in human stories. Rule: stay with one point-of-view character unless the story needs more. (Fiction only.)
- **Narrator temporal distance, distant retrospective:** a GPT fingerprint. GPT tends to frame stories as reflections on events from years or decades ago (p. 9). Rule: do not default to a narrator looking back; tell the story from inside its own time unless the story needs the distance.

Deliberately left out: narrator presence and visibility, and heteroglossia (no direction given in the paper); mostly direct speech (a Gemini fingerprint). GPT habits are collected in `ref-gpt-fingerprint.md`.

## Self-check questions

### Nonfiction (speeches, briefs, articles, talking points, proposals)
1. Does any paragraph end by explaining what the point means or teaches? Cut it unless the genre requires a stated recommendation.
2. Are sources, laws, reports, and people named, or only alluded to?
3. Is the conclusion tidier than the evidence? Keep open questions open.
4. Is every section the same length and weight? Let the important point take more room.
5. Does it open with scene-setting or preamble before the actual point?
6. In speeches: is the audience addressed directly at least once where natural?
7. Is there any direct quotation from a real person, where one is available in the source material?

### Fiction and narrative
1. Does the narrator state the theme or lesson?
2. Is there only one plot line, told in order from start to finish?
3. Does the protagonist resolve everything through their own choice or a moment of understanding?
4. Are emotions shown only through bodily sensations and setting?
5. Are there smells, weather, and environmental detail in every scene?
6. Are other works, places, and brands named, or only alluded to?
7. Is the protagonist clearly good? Could they be more mixed?
8. Does the ending include an epilogue or quiet summary? (See ref-gpt-fingerprint.md.)
9. Does the point of view move between characters without a reason?
