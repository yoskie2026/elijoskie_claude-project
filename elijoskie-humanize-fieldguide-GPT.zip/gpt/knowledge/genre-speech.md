# Genre profile: speeches and talking points

Covers: speeches, remarks, keynotes, addresses, toasts, provocations, panel notes, talking points, presentation scripts.

## Evidence base
No AI-versus-human study of speeches was found. This profile draws on evidence from other genres that transfers to spoken delivery (Jiang and Hyland 2025 on engagement; StoryScope on reader address and emotion; Munoz-Ortiz et al. on rhythm) and on speechwriting convention. Items marked **[convention]** rest on convention only.

## Settings

| Setting | Speech setting |
|---|---|
| Stance | Strong and personal. First person is expected. |
| Reader address | Address the audience directly ("you", "all of us here"). Rhetorical questions are normal. ChatGPT essays use fewer questions and personal asides than human writers (Jiang and Hyland). |
| Rhythm | Wider variation than written genres: short punchy sentences next to longer ones. **[convention]** |
| Repetition | Deliberate repetition of a key phrase is a legitimate speech device. The synonym-cycling rule matters most here: repeat the phrase, do not vary it. **[convention]** |
| Rule of three | A deliberate triad at a key moment is a classic device. The tell is triads everywhere by habit (Wikipedia p. 11). Limit to one or two deliberate uses. **[convention]** |
| Conclusions | End on a concrete ask, commitment, or image. Not a summary of every point. |
| Stories inside the speech | Named people, places, dates. Name feelings plainly ("she was frightened"); do not default to bodily sensations (StoryScope Table 15). |
| Formatting | Written for the ear. No bullets or headings in the delivered text. |

## Talking points (default format, from the user's standing preference)
- Use the project or topic as a heading. Do not narrate what the speaker did ("I led X").
- Under each heading, list the lessons or findings directly.
- Open each bullet with a conversational lead-in ("What we learned was that...", "We also found that...").
- Keep the bullets connected to each other, so they can be spoken in sequence.
- Plain, complete sentences. No academic or poetic phrasing.

## Speech-specific AI tells
- A voice that could belong to anyone. Name the event, the audience, the city, and the people in the room.
- Stacked abstractions: "innovation, inclusion, and sustainable impact".
- Explaining the moral of every story (StoryScope: narrators state the theme 77% of the time in AI stories, 52% in human stories).
- Uniform sentence length that sounds flat when read aloud.
- An uplifting closing that restates everything.

## Self-check
1. Read it aloud. Does any sentence feel unnatural to say?
2. Is the audience addressed directly at least once?
3. Are stories specific enough to be checked?
4. Is there one clear ask or takeaway at the end?
5. Are triads and repetition deliberate, not habitual?
