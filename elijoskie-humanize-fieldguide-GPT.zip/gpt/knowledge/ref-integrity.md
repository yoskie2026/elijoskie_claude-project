# Integrity checklist

Sources: Wikipedia "Signs of AI writing" (pp. 2-3, 5, 18, 27-30, 39); StoryScope (p. 7). This layer covers whether claims are specific, sourced, and real. It matters most for policy, research, and grant writing.

## Rules

1. **Specific over generic.** LLMs tend to drop rare, specific facts and replace them with common, positive, important-sounding descriptions. The Wikipedia example: "inventor of the first train-coupling device" becomes "a revolutionary titan of industry" (pp. 2-3). Keep the specific fact.
2. **No invented attributions.** Newer tools attach interpretation to named sources whether or not the source says it (p. 4). Only attribute a claim to a source that makes it.
3. **No inflated source counts.** Do not present one or two sources as "experts", "scholars", or "several publications" (p. 5).
4. **No gap-filling speculation.** Phrases such as "not widely documented", "likely", "keeps personal details private" often introduce speculative or fabricated content (p. 18). If information is missing, say so or leave it out.
5. **Every citation must be checkable.**
   - Book citations need page numbers. A book citation without a page number cannot verify the claim (p. 28).
   - Cited pages must actually support the claim. The source shows a real book with a real page that does not contain the cited idea (p. 29).
   - DOIs must resolve to the cited article. AI produces valid-looking DOIs that point to unrelated papers (p. 28).
   - Links must be live and real. Several dead links that were never archived is a strong sign of fabrication (p. 27).
   - ISBNs must pass the checksum (p. 27).
   - Strip tracking parameters (utm_source=chatgpt.com, etc.) from URLs (p. 30).
6. **Do not cite what you have not seen.** If the GPT cannot verify a source in the current session, it must say the citation is unverified.
7. **Name real things.** AI avoids naming real brands, places, or works (StoryScope p. 7). Where the material supports it, name them.
8. **Political content.** The Wikipedia page reports that frontier models show a pro-authoritarian lean on some prompts and are more likely to criticise governments in freer countries (p. 39, citing WSJ and Fortune reporting from August 2026). For policy writing on governance, check that criticism and praise are applied evenly.
