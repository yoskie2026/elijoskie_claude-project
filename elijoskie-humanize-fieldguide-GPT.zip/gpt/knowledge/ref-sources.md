# Sources, evidence strength, and limits

Last reviewed: September 2026. Review every three months. Where a page number is given, it was checked against the source; where only a section or table is given, the page was not verified.

## Core sources

**1. Wikipedia, "Signs of AI writing"** (WikiProject AI Cleanup advice page)
- Revision used: https://en.wikipedia.org/w/index.php?title=Wikipedia:Signs_of_AI_writing&oldid=1375746757 (page numbers refer to the 48-page print dated 19 Sept 2026)
- Status: advice page, not policy, not community-reviewed (p. 1). Built for detecting undisclosed AI content on Wikipedia; warns that treating the signs as the problems can make detection harder (p. 1). Informational writing only; fiction tells excluded (p. 44).
- Evidence: mixed (peer-reviewed studies, preprints, press, blogs, individual edits).

**2. Russell, Rajendhran, Iyyer, and Wieting (2026). "StoryScope: Investigating idiosyncrasies in AI fiction."** arXiv:2604.03136v1. https://arxiv.org/abs/2604.03136
- Status: preprint under review; v1 contains an unresolved author note (p. 9). Fiction only. Features found and scored by LLMs; human validation on 12 stories (p. 19). Text-level classifiers still reached 99.7% or higher (Table 2, p. 6).

## Supporting studies

**3. Reinhart, Markey, Laudenbach, Pantusen, Yurko, Weinberg, and Brown (2025). "Do LLMs write like humans? Variation in grammatical and rhetorical styles."** PNAS 122(8). https://doi.org/10.1073/pnas.2422455122 (preprint: https://arxiv.org/abs/2410.16107). Peer-reviewed. Models: Llama 3 variants, GPT-4o, GPT-4o Mini.

**4. Herbold, Hautli-Janisz, Heuer, Kikteva, and Trautsch (2023). "A large-scale comparison of human-written versus ChatGPT-generated essays."** Scientific Reports 13, 18617. https://doi.org/10.1038/s41598-023-45644-9 (linguistic results in Tables 3 and 4). Peer-reviewed. German high-school argumentative essays.

**5. Jiang and Hyland (2025). "Does ChatGPT write like a student? Engagement markers in argumentative essays."** Written Communication 42(3), 463-492. https://doi.org/10.1177/07410883251328311. Peer-reviewed. 145 essays per group.

**6. Munoz-Ortiz, Gomez-Rodriguez, and Vilares (2024). "Contrasting linguistic patterns in human and LLM-generated news text."** Artificial Intelligence Review. https://doi.org/10.1007/s10462-024-10903-2. Peer-reviewed. 2023 open models.

**7. Ju, Blix, and Williams (2025). "Domain Regeneration: How well do LLMs match syntactic properties of text domains?"** Findings of ACL 2025, pp. 2367-2388. https://aclanthology.org/2025.findings-acl.120/. Peer-reviewed. Llama and Mistral models.

**8. Shaib, Chakrabarty, Garcia-Olano, and Wallace. "Measuring AI 'slop' in text."** arXiv:2509.19163v2 (January 2026). https://arxiv.org/abs/2509.19163. Preprint. Taxonomy in Table 1; predictors in Section 5.1; LLM-judge results in Table 7.

**9. Chakrabarty, Laban, and Wu (2025). "Can AI writing be salvaged? Mitigating idiosyncrasies and improving human-AI alignment in the writing process through edits."** CHI 2025. https://arxiv.org/abs/2409.14509. Peer-reviewed. Creative writing.

**10. Russell, Karpinska, and Iyyer (2025). "People who frequently use ChatGPT for writing tasks are accurate and robust detectors of AI-generated text."** ACL 2025, pp. 5342-5373. https://aclanthology.org/2025.acl-long.267/. Peer-reviewed. Nonfiction articles.

**11. Liang, Yuksekgonul, Mao, Wu, and Zou (2023). "GPT detectors are biased against non-native English writers."** Patterns 4(7). https://doi.org/10.1016/j.patter.2023.100779. Peer-reviewed opinion paper with original data.

## Coverage by genre
| Genre profile | Direct AI-vs-human evidence |
|---|---|
| Research | Yes (essays, academic abstracts, register) |
| Articles, op-eds, essays | Yes (news, nonfiction articles, argumentative essays) |
| Fiction | Yes (StoryScope, LAMP) |
| Policy briefs | Indirect (nonfiction, news, informational) |
| Speeches and talking points | None found; convention plus transferable findings |
| Grant proposals | None found; convention plus Wikipedia content patterns |

## Known limits
- This GPT runs on OpenAI models. GPT-specific evidence: GPT-5.4 in StoryScope; GPT-4o in Reinhart et al. and Russell et al.; GPT-4, GPT-4o, and GPT-5 vocabulary eras and ChatGPT markup in Wikipedia. The ChatGPT model behind this GPT may be newer than any of these.
- Most studies test models from 2023 to 2025. Claude-specific data is thin: Claude Sonnet 4.6 in StoryScope, a Claude model in Russell et al. 2025, and press-reported em dash data.
- Scanner thresholds for rhythm and grammar are heuristics chosen for this skill, not values from the studies. The studies give ratios between AI and human text, not fixed human baselines.
- Following these rules reduces documented patterns. It does not make text undetectable, and it does not replace a human edit.

## Use note
These rules aim at better writing: specific, sourced, varied, and fitted to the genre. They do not change any obligation to disclose AI assistance where a funder, client, publisher, or institution requires it.
