# Genre profile: fiction and narrative

Covers: short stories, fiction, scenes, scripts, screenplays, narrative pieces.

## Evidence base
Direct evidence: StoryScope (Russell et al. 2026 preprint; full detail in `ref-structure.md`), Chakrabarty et al. 2025 (LAMP; creative writing edited by professional writers), Wikipedia note (a), p. 44.

## Settings

| Setting | Fiction setting |
|---|---|
| Theme | Do not state the moral. AI narrators state the theme 77% of the time, human narrators 52% (StoryScope Table 15). |
| Resolution | Endings can be ambiguous, unresolved, or driven by outside events. AI resolutions favour protagonist choice (69% vs 46%) and internal understanding (47% vs 27%). |
| Emotion | Name feelings plainly at least some of the time. AI conveys emotion through the body 81% of the time vs 38% for humans. |
| Senses and setting | Lower the default level of sensory detail, smells, and weather-as-mood. |
| Structure | Subplots, time jumps, and flashbacks are allowed and more human (StoryScope Table 15). |
| Characters | Morally mixed protagonists are more common in human stories (59% vs 38%). |
| Point of view | Stay with one point-of-view character unless the story needs more. "Single focal character" is a human fingerprint feature (StoryScope Table 16, p. 27). |
| References | Name real books, places, and brands where natural (47% vs 24%). |
| Reader address | Optional. Human stories use it more than AI stories, but most human stories do not use it at all (see the note in `ref-structure.md`). |
| Plot mechanism | Do not default to gossip and rumour as the engine of the plot. GPT uses them in 64% of stories vs 44-55% for other sources (StoryScope p. 9). |
| Narrator distance | Do not default to a narrator looking back on events from years or decades ago, a GPT fingerprint (StoryScope p. 9, Table 16). |
| Ending | End at the last event that matters. No summarising coda. |

## LAMP categories to edit out (Chakrabarty et al.)
Cliche, unnecessary or redundant exposition, purple prose, poor sentence structure, lack of specificity and detail, awkward word choice and phrasing, tense inconsistency.

## Self-check
Use the fiction questions in `ref-structure.md`.
