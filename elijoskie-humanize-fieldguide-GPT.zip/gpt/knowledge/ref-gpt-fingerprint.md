# GPT and ChatGPT habits

Read on every drafting task. These are documented tendencies of OpenAI models in the sources used by this GPT. The ChatGPT model running this GPT may be newer; treat these as dated observations (as of September 2026).

## From Wikipedia, "Signs of AI writing"
- **Vocabulary by era (pp. 7-8).** GPT-4 (2023 to mid-2024): Additionally, boasts, bolstered, crucial, delve, emphasizing, enduring, garner, intricate, interplay, key, landscape, meticulous, pivotal, underscore, tapestry, testament, valuable, vibrant. GPT-4o (mid-2024 to mid-2025): align with, bolstered, crucial, emphasizing, enhance, enduring, fostering, highlighting, pivotal, showcasing, underscore, vibrant. GPT-5 (mid-2025 on): emphasizing, enhance, highlighting, showcasing, plus notability and media-coverage phrasing.
- **Notability talk (p. 4).** Emphasis on coverage in "independent", "national", or "trade" outlets is more common in text from AI tools released in 2025 or later. Say what the coverage reported instead.
- **Distance from human writing (p. 8).** GPT-4o output varied more from human writing than other contemporaneous models.
- **Broader context and length (p. 39).** ChatGPT focuses on broader context more than Gemini and Claude, and its responses are less concise. Cut context the reader did not ask for.
- **Positivity (p. 5).** Older GPT-4 output was more blatantly positive; newer models are subtly positive. Check for default upbeat framing.
- **Curly quotes (p. 15).** ChatGPT typically uses curly quotation marks and apostrophes. Weak signal on its own; keep quote style consistent with the document.
- **Em dashes (p. 14).** OpenAI worked to suppress them in GPT-5.1; a July 2026 study reported ChatGPT used them less than professional writers. Still do not use them.
- **Leftover markup (pp. 22-23, 30).** contentReference, oaicite, oai_citation, turn0search0, attributableIndex, and utm_source=chatgpt.com or utm_source=openai in URLs. Remove all of them.

## From Reinhart et al. 2025 (PNAS)
- GPT-4o used the agentless passive at about half the human rate, and instruction-tuned models (including GPT-4o) used participial clauses and nominalizations at well above human rates. Keep a normal amount of passive; cut "-ing" add-on clauses and decorative nominalizations.

## From StoryScope (GPT-5.4, fiction; p. 9, Tables 5 and 16)
- **Gossip and rumour** as a plot mechanism (64% vs 44-55% for other sources).
- **Distant retrospective narration:** stories framed as reflections on events from years or decades ago.
- **Social, ensemble-heavy storytelling.**
- **Subverts expectations more than other AI sources (41% vs 27-36%) and leaves reconciliations ambiguous.** These are closer to human writing; no change needed.
- **Length adherence (Table 5):** GPT-5.4 wrote long stories (mean 6,651 words) and landed within 10% of the requested length only 9.6% of the time. When a word count is given, check it.

## From Shaib et al. (preprint)
- GPT-5 agreed poorly with expert human judges on what counts as low-quality AI text and was weak at finding the problem spans (Table 7). The GPT's self-check supports, and does not replace, a human edit.
